'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { callAIAgent } from '@/lib/aiAgent'
import parseLLMJson from '@/lib/jsonParser'
import { FiTruck, FiMapPin, FiAlertTriangle, FiLogOut, FiClock, FiCheckCircle, FiNavigation, FiUser, FiActivity, FiChevronDown, FiChevronUp } from 'react-icons/fi'
import { BiLoaderAlt } from 'react-icons/bi'
import { HiOutlineStatusOnline } from 'react-icons/hi'

const DRIVER_AGENT_ID = '69b2edd98d90feca9f3daba2'

import type { Emergency } from './ControlRoomSection'

interface DriverDashboardSectionProps {
  user: { username: string; role: string }
  onLogout: () => void
  emergencies: Emergency[]
}

function renderMarkdown(text: string) {
  if (!text) return null
  return (
    <div className="space-y-1.5">
      {text.split('\n').map((line, i) => {
        if (line.startsWith('### ')) return <h4 key={i} className="font-semibold text-sm mt-2 mb-1">{line.slice(4)}</h4>
        if (line.startsWith('## ')) return <h3 key={i} className="font-semibold text-base mt-2 mb-1">{line.slice(3)}</h3>
        if (line.startsWith('# ')) return <h2 key={i} className="font-bold text-lg mt-3 mb-1">{line.slice(2)}</h2>
        if (line.startsWith('- ') || line.startsWith('* ')) return <li key={i} className="ml-4 list-disc text-sm">{formatInline(line.slice(2))}</li>
        if (/^\d+\.\s/.test(line)) return <li key={i} className="ml-4 list-decimal text-sm">{formatInline(line.replace(/^\d+\.\s/, ''))}</li>
        if (!line.trim()) return <div key={i} className="h-1" />
        return <p key={i} className="text-sm">{formatInline(line)}</p>
      })}
    </div>
  )
}

function formatInline(text: string) {
  const parts = text.split(/\*\*(.*?)\*\*/g)
  if (parts.length === 1) return text
  return parts.map((part, i) => i % 2 === 1 ? <strong key={i} className="font-semibold">{part}</strong> : part)
}

export default function DriverDashboardSection({ user, onLogout, emergencies }: DriverDashboardSectionProps) {
  const [activeMenu, setActiveMenu] = useState('emergency')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [navBriefing, setNavBriefing] = useState<any>(null)
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({ urgency: true, navigation: true, driving: true, preArrival: true, alerts: true })

  const myEmergency = emergencies.find(em => em.status !== 'completed') || (emergencies.length > 0 ? emergencies[0] : null)

  const toggleSection = (key: string) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const handleGetBriefing = async () => {
    if (!myEmergency) return
    setError('')
    setLoading(true)
    const message = `Driver navigation briefing request: I need to navigate from my current location to the accident at ${myEmergency.accidentLocation} (Lat: ${myEmergency.accidentLat}, Lng: ${myEmergency.accidentLng}), then transport the patient to ${myEmergency.hospital} (Lat: ${myEmergency.hospitalLat}, Lng: ${myEmergency.hospitalLng}). Patient condition: ${myEmergency.patientCondition}. Ambulance: ${myEmergency.driver.ambulanceNo}. Please provide urgency assessment, navigation steps, driving guidance, pre-arrival notes, route summary, and any critical alerts.`
    try {
      const result = await callAIAgent(message, DRIVER_AGENT_ID)
      if (result.success) {
        const parsed = parseLLMJson(result?.response?.result || result?.response)
        setNavBriefing(parsed)
      } else {
        setError(result?.error ?? 'Failed to get navigation briefing')
      }
    } catch {
      setError('Network error. Please try again.')
    }
    setLoading(false)
  }

  const statusSteps = [
    { key: 'dispatched', label: 'Dispatched' },
    { key: 'en-route-accident', label: 'En-Route to Accident' },
    { key: 'at-accident', label: 'At Accident' },
    { key: 'en-route-hospital', label: 'En-Route to Hospital' },
    { key: 'arrived', label: 'Arrived' },
  ]

  const currentStepIndex = !myEmergency ? 0
    : myEmergency.status === 'dispatched' ? 0
    : myEmergency.status === 'en-route' ? (myEmergency.animProgress < 50 ? 1 : myEmergency.animProgress < 75 ? 2 : 3)
    : 4

  const menuItems = [
    { id: 'emergency', label: 'My Emergency', icon: FiAlertTriangle },
    { id: 'navigation', label: 'Navigation', icon: FiNavigation },
    { id: 'status', label: 'Status', icon: FiActivity },
  ]

  const SectionToggle = ({ sectionKey, title, icon: Icon, children }: { sectionKey: string; title: string; icon: React.ElementType; children: React.ReactNode }) => (
    <div className="rounded-[0.625rem] bg-white/50 border border-border/30 overflow-hidden">
      <button onClick={() => toggleSection(sectionKey)} className="w-full flex items-center justify-between p-3 hover:bg-white/30 transition-all">
        <span className="flex items-center gap-2 text-sm font-medium text-foreground"><Icon className="w-4 h-4 text-primary" />{title}</span>
        {expandedSections[sectionKey] ? <FiChevronUp className="w-4 h-4 text-muted-foreground" /> : <FiChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>
      {expandedSections[sectionKey] && <div className="px-3 pb-3 border-t border-border/20 pt-2">{children}</div>}
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(350,35%,97%)] via-[hsl(340,30%,95%)] to-[hsl(330,25%,96%)] flex">
      {/* Sidebar */}
      <aside className="w-64 min-h-screen backdrop-blur-[16px] bg-white/60 border-r border-white/[0.18] flex flex-col">
        <div className="p-5 flex items-center gap-2 border-b border-border/50">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <FiTruck className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-semibold tracking-tight text-foreground">RapidRoute</span>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {menuItems.map(item => (
            <button key={item.id} onClick={() => setActiveMenu(item.id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[0.625rem] text-sm font-medium transition-all duration-200 ${activeMenu === item.id ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'}`}>
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-border/50 space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <FiUser className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{user.username}</p>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Ambulance Driver</Badge>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onLogout} className="w-full justify-start text-muted-foreground">
            <FiLogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-5 space-y-5">
        {/* Status Strip */}
        <div className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] p-4 shadow-sm">
          <div className="flex items-center justify-between">
            {statusSteps.map((step, idx) => (
              <React.Fragment key={step.key}>
                <div className="flex flex-col items-center gap-1">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${idx <= currentStepIndex ? 'bg-primary text-primary-foreground shadow-md' : 'bg-muted text-muted-foreground'}`}>
                    {idx < currentStepIndex ? <FiCheckCircle className="w-4 h-4" /> : idx + 1}
                  </div>
                  <span className={`text-[10px] font-medium text-center leading-tight max-w-[70px] ${idx <= currentStepIndex ? 'text-primary' : 'text-muted-foreground'}`}>{step.label}</span>
                </div>
                {idx < statusSteps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-1 rounded-full transition-all ${idx < currentStepIndex ? 'bg-primary' : 'bg-muted'}`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Emergency Details */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiAlertTriangle className="w-4 h-4 text-primary" /> Emergency Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!myEmergency ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FiTruck className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No active emergency assigned</p>
                  <p className="text-xs mt-1">Waiting for dispatch from Control Room</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-muted-foreground">{myEmergency.id}</span>
                    <Badge variant={myEmergency.severityLevel?.toLowerCase() === 'critical' ? 'destructive' : 'default'} className="text-xs">
                      {myEmergency.severityLevel ?? 'HIGH'}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="bg-muted/30 rounded-lg p-2.5">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Accident Location</p>
                      <p className="font-medium text-foreground flex items-center gap-1"><FiMapPin className="w-3 h-3 text-red-500 shrink-0" />{myEmergency.accidentLocation}</p>
                    </div>
                    <div className="bg-muted/30 rounded-lg p-2.5">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Hospital</p>
                      <p className="font-medium text-foreground flex items-center gap-1"><HiOutlineStatusOnline className="w-3 h-3 text-blue-500 shrink-0" />{myEmergency.hospital}</p>
                    </div>
                    <div className="bg-muted/30 rounded-lg p-2.5">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Patient Condition</p>
                      <p className="font-medium text-foreground">{myEmergency.patientCondition}</p>
                    </div>
                    <div className="bg-muted/30 rounded-lg p-2.5">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">ETA</p>
                      <p className="font-medium text-foreground flex items-center gap-1"><FiClock className="w-3 h-3 text-primary shrink-0" />{myEmergency.eta}</p>
                    </div>
                  </div>
                  {/* Progress bar */}
                  <div>
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Progress</span><span>{Math.round(myEmergency.animProgress)}%</span>
                    </div>
                    <div className="w-full bg-muted/50 rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full transition-all duration-300" style={{ width: `${myEmergency.animProgress}%` }} />
                    </div>
                  </div>
                  <Button onClick={handleGetBriefing} disabled={loading} className="w-full rounded-[0.625rem] h-10 font-semibold">
                    {loading ? <><BiLoaderAlt className="w-4 h-4 mr-2 animate-spin" /> Getting Briefing...</> : <><FiNavigation className="w-4 h-4 mr-1" /> Get Navigation Briefing</>}
                  </Button>
                  {error && <p className="text-destructive text-xs bg-destructive/10 px-3 py-2 rounded-lg">{error}</p>}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Simulated Map */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiMapPin className="w-4 h-4 text-primary" /> Route Map
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative h-[280px] bg-gradient-to-br from-green-100/60 via-emerald-50/40 to-teal-100/60 overflow-hidden">
                <div className="absolute inset-0 opacity-10">
                  {[...Array(8)].map((_, i) => (
                    <React.Fragment key={i}>
                      <div className="absolute h-px bg-foreground/30 w-full" style={{ top: `${(i + 1) * 12.5}%` }} />
                      <div className="absolute w-px bg-foreground/30 h-full" style={{ left: `${(i + 1) * 12.5}%` }} />
                    </React.Fragment>
                  ))}
                </div>
                {myEmergency ? (
                  <>
                    <div className="absolute top-[20%] left-[15%] z-10">
                      <div className="w-5 h-5 bg-red-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center animate-pulse">
                        <FiAlertTriangle className="w-3 h-3 text-white" />
                      </div>
                      <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[8px] font-medium text-red-600 whitespace-nowrap bg-white/80 px-1 rounded">Pickup</span>
                    </div>
                    <div className="absolute bottom-[20%] right-[15%] z-10">
                      <div className="w-5 h-5 bg-blue-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                        <span className="text-[8px] font-bold text-white">H</span>
                      </div>
                      <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[8px] font-medium text-blue-600 whitespace-nowrap bg-white/80 px-1 rounded">Hospital</span>
                    </div>
                    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                      <path d="M15,22 C30,22 35,40 50,50 C65,60 75,78 85,78" fill="none" stroke="hsl(346,77%,50%)" strokeWidth="0.6" strokeDasharray="2,1" opacity="0.7" />
                    </svg>
                    <div className="absolute z-20 transition-all duration-200" style={{ top: `${22 + (myEmergency.animProgress / 100) * 56}%`, left: `${15 + (myEmergency.animProgress / 100) * 70}%`, transform: 'translate(-50%,-50%)' }}>
                      <div className="w-6 h-6 bg-primary rounded-full border-2 border-white shadow-xl flex items-center justify-center animate-pulse">
                        <FiTruck className="w-3 h-3 text-primary-foreground" />
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm">
                    <p>No route to display</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Navigation Briefing */}
        {navBriefing && (
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiNavigation className="w-4 h-4 text-primary" /> AI Navigation Briefing
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[450px]">
                <div className="space-y-3">
                  {/* Urgency Assessment */}
                  {navBriefing.urgency_assessment && (
                    <SectionToggle sectionKey="urgency" title="Urgency Assessment" icon={FiAlertTriangle}>
                      <div className="space-y-2 text-sm">
                        {navBriefing.urgency_assessment?.level && (
                          <Badge variant="destructive" className="text-xs">{navBriefing.urgency_assessment.level}</Badge>
                        )}
                        {navBriefing.urgency_assessment?.condition_summary && (
                          <p className="text-foreground">{navBriefing.urgency_assessment.condition_summary}</p>
                        )}
                        {navBriefing.urgency_assessment?.time_sensitivity && (
                          <p className="text-muted-foreground text-xs flex items-center gap-1"><FiClock className="w-3 h-3" />{navBriefing.urgency_assessment.time_sensitivity}</p>
                        )}
                      </div>
                    </SectionToggle>
                  )}

                  {/* Navigation Steps */}
                  {navBriefing.navigation_briefing && (
                    <SectionToggle sectionKey="navigation" title="Navigation Steps" icon={FiNavigation}>
                      <div className="space-y-3 text-sm">
                        {Array.isArray(navBriefing.navigation_briefing?.to_accident) && navBriefing.navigation_briefing.to_accident.length > 0 && (
                          <div>
                            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">To Accident Site</p>
                            <ol className="space-y-1">
                              {navBriefing.navigation_briefing.to_accident.map((step: string, i: number) => (
                                <li key={i} className="flex items-start gap-2 text-foreground">
                                  <span className="w-5 h-5 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-[10px] font-semibold shrink-0 mt-0.5">{i + 1}</span>
                                  {step}
                                </li>
                              ))}
                            </ol>
                          </div>
                        )}
                        {Array.isArray(navBriefing.navigation_briefing?.to_hospital) && navBriefing.navigation_briefing.to_hospital.length > 0 && (
                          <div>
                            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">To Hospital</p>
                            <ol className="space-y-1">
                              {navBriefing.navigation_briefing.to_hospital.map((step: string, i: number) => (
                                <li key={i} className="flex items-start gap-2 text-foreground">
                                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-[10px] font-semibold shrink-0 mt-0.5">{i + 1}</span>
                                  {step}
                                </li>
                              ))}
                            </ol>
                          </div>
                        )}
                        <div className="flex gap-3">
                          {navBriefing.navigation_briefing?.total_distance && (
                            <Badge variant="secondary" className="text-xs"><FiMapPin className="w-3 h-3 mr-1" />{navBriefing.navigation_briefing.total_distance}</Badge>
                          )}
                          {navBriefing.navigation_briefing?.estimated_duration && (
                            <Badge variant="secondary" className="text-xs"><FiClock className="w-3 h-3 mr-1" />{navBriefing.navigation_briefing.estimated_duration}</Badge>
                          )}
                        </div>
                      </div>
                    </SectionToggle>
                  )}

                  {/* Driving Guidance */}
                  {Array.isArray(navBriefing.driving_guidance) && navBriefing.driving_guidance.length > 0 && (
                    <SectionToggle sectionKey="driving" title="Driving Guidance" icon={FiTruck}>
                      <ul className="space-y-1.5">
                        {navBriefing.driving_guidance.map((tip: string, i: number) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                            <FiCheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 shrink-0" />{tip}
                          </li>
                        ))}
                      </ul>
                    </SectionToggle>
                  )}

                  {/* Pre-Arrival Notes */}
                  {Array.isArray(navBriefing.pre_arrival_notes) && navBriefing.pre_arrival_notes.length > 0 && (
                    <SectionToggle sectionKey="preArrival" title="Pre-Arrival Notes" icon={FiActivity}>
                      <ul className="space-y-1.5">
                        {navBriefing.pre_arrival_notes.map((note: string, i: number) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                            <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />{note}
                          </li>
                        ))}
                      </ul>
                    </SectionToggle>
                  )}

                  {/* Critical Alerts */}
                  {Array.isArray(navBriefing.critical_alerts) && navBriefing.critical_alerts.length > 0 && (
                    <SectionToggle sectionKey="alerts" title="Critical Alerts" icon={FiAlertTriangle}>
                      <div className="space-y-1.5">
                        {navBriefing.critical_alerts.map((alert: string, i: number) => (
                          <div key={i} className="flex items-start gap-2 text-sm text-red-700 bg-red-50 rounded-lg p-2">
                            <FiAlertTriangle className="w-3.5 h-3.5 text-red-500 mt-0.5 shrink-0" />{alert}
                          </div>
                        ))}
                      </div>
                    </SectionToggle>
                  )}

                  {/* Route Summary */}
                  {navBriefing.route_summary && (
                    <div className="bg-muted/30 rounded-lg p-3">
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Route Summary</p>
                      <div className="text-sm text-foreground">{renderMarkdown(navBriefing.route_summary)}</div>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        )}

        {/* Agent Info */}
        <div className="backdrop-blur-[16px] bg-white/50 border border-white/[0.18] rounded-[0.875rem] p-3">
          <p className="text-xs text-muted-foreground mb-1 font-medium">Powered by AI Agents</p>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${loading ? 'bg-amber-400 animate-pulse' : 'bg-green-400'}`} />
              <span className="text-foreground">Driver Navigation Agent</span>
              <span className="text-muted-foreground font-mono text-[10px]">{DRIVER_AGENT_ID.slice(0, 8)}...</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
