'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { callAIAgent } from '@/lib/aiAgent'
import parseLLMJson from '@/lib/jsonParser'
import { FiTruck, FiActivity, FiMapPin, FiAlertTriangle, FiLogOut, FiClock, FiCheckCircle, FiNavigation, FiSend, FiX, FiUser, FiPhone, FiSmartphone, FiRadio, FiBell } from 'react-icons/fi'
import { HiOutlineStatusOnline } from 'react-icons/hi'
import { BiLoaderAlt } from 'react-icons/bi'

// Simulated nearby citizens near traffic signals and junctions
const NEARBY_CITIZENS = [
  { id: 'C001', name: 'Citizen near Signal A', phone: '+91-9XXXX-XX101', location: 'Traffic Signal - MG Road Junction', mapTop: 35, mapLeft: 38 },
  { id: 'C002', name: 'Citizen near Signal B', phone: '+91-9XXXX-XX202', location: 'Traffic Signal - Ring Road Crossing', mapTop: 48, mapLeft: 55 },
  { id: 'C003', name: 'Citizen near Signal C', phone: '+91-9XXXX-XX303', location: 'Traffic Signal - Hospital Road', mapTop: 58, mapLeft: 68 },
  { id: 'C004', name: 'Citizen near Jam Zone', phone: '+91-9XXXX-XX404', location: 'Traffic Jam - Highway Entry', mapTop: 30, mapLeft: 45 },
  { id: 'C005', name: 'Citizen near Jam Zone', phone: '+91-9XXXX-XX505', location: 'Traffic Jam - Market Square', mapTop: 42, mapLeft: 50 },
]

interface CitizenSmsLog {
  id: string
  citizenId: string
  citizenName: string
  phone: string
  location: string
  ambulanceNo: string
  message: string
  timestamp: string
  delivered: boolean
}

const DISPATCH_AGENT_ID = '69b2edd988c4456ed85f57ed'

const DEMO_DATASETS = [
  { id: 1, name: 'Dataset 1 - Mumbai', accidentLat: 19.076, accidentLng: 72.8777, accidentLocation: 'Marine Drive, Mumbai', hospital: 'Lilavati Hospital', hospitalLat: 19.0509, hospitalLng: 72.8294 },
  { id: 2, name: 'Dataset 2 - Delhi', accidentLat: 28.6139, accidentLng: 77.209, accidentLocation: 'Connaught Place, Delhi', hospital: 'AIIMS Delhi', hospitalLat: 28.5672, hospitalLng: 77.21 },
  { id: 3, name: 'Dataset 3 - Bangalore', accidentLat: 12.9716, accidentLng: 77.5946, accidentLocation: 'MG Road, Bangalore', hospital: 'Manipal Hospital', hospitalLat: 12.9631, hospitalLng: 77.5975 },
]

const DRIVERS = [
  { id: 'D001', name: 'Rajesh Kumar', ambulanceNo: 'KA-01-AB-1234' },
  { id: 'D002', name: 'Suresh Patel', ambulanceNo: 'MH-02-CD-5678' },
  { id: 'D003', name: 'Arun Singh', ambulanceNo: 'DL-03-EF-9012' },
]

const PATIENT_CONDITIONS = ['Heart Attack', 'Blood Loss', 'Trauma', 'Oxygen Critical', 'Pregnant Emergency', 'Accident Injury']
const HOSPITALS = ['Lilavati Hospital', 'AIIMS Delhi', 'Manipal Hospital', 'Apollo Hospital', 'Fortis Hospital']

export interface Emergency {
  id: string
  accidentLocation: string
  accidentLat: number
  accidentLng: number
  hospital: string
  hospitalLat: number
  hospitalLng: number
  driver: typeof DRIVERS[0]
  patientCondition: string
  status: 'dispatched' | 'en-route' | 'completed'
  eta: string
  dispatchBriefing: string
  routeRecommendation: any
  hospitalNotification: any
  severityLevel: string
  recommendedActions: string[]
  animProgress: number
  timestamp: string
}

interface ControlRoomSectionProps {
  user: { username: string; role: string }
  onLogout: () => void
  emergencies: Emergency[]
  setEmergencies: React.Dispatch<React.SetStateAction<Emergency[]>>
  smsAlert: { show: boolean; message: string; ambulance: string }
  setSmsAlert: React.Dispatch<React.SetStateAction<{ show: boolean; message: string; ambulance: string }>>
}

export default function ControlRoomSection({ user, onLogout, emergencies, setEmergencies, smsAlert, setSmsAlert }: ControlRoomSectionProps) {
  const [activeMenu, setActiveMenu] = useState('dashboard')
  const [filterStatus, setFilterStatus] = useState('all')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [selectedDataset, setSelectedDataset] = useState('')
  const [form, setForm] = useState({
    accidentLocation: '', accidentLat: '', accidentLng: '',
    hospital: '', driver: '', patientCondition: '',
  })
  const [latestDispatch, setLatestDispatch] = useState<any>(null)
  const [citizenSmsLogs, setCitizenSmsLogs] = useState<CitizenSmsLog[]>([])
  const [citizenAlert, setCitizenAlert] = useState<{ show: boolean; citizens: CitizenSmsLog[] }>({ show: false, citizens: [] })
  const alertedCitizensRef = useRef<Set<string>>(new Set())
  const animRef = useRef<NodeJS.Timeout | null>(null)

  // Trigger device vibration for citizen SMS alerts
  const triggerVibration = useCallback(() => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      // Strong vibration pattern: vibrate-pause-vibrate-pause-vibrate (emergency pattern)
      navigator.vibrate([300, 100, 300, 100, 500, 200, 300, 100, 300])
    }
  }, [])

  const handleDatasetChange = (val: string) => {
    setSelectedDataset(val)
    const ds = DEMO_DATASETS.find(d => d.id.toString() === val)
    if (ds) {
      setForm(prev => ({
        ...prev,
        accidentLocation: ds.accidentLocation,
        accidentLat: ds.accidentLat.toString(),
        accidentLng: ds.accidentLng.toString(),
        hospital: ds.hospital,
      }))
    }
  }

  const startAnimation = useCallback((emergencyId: string) => {
    alertedCitizensRef.current = new Set()
    const interval = setInterval(() => {
      setEmergencies(prev => {
        const updated = prev.map(em => {
          if (em.id !== emergencyId) return em
          const newProg = em.animProgress + 0.5
          let newStatus = em.status
          if (newProg >= 50 && em.status === 'dispatched') newStatus = 'en-route'
          if (newProg >= 100) newStatus = 'completed'

          // Hospital proximity SMS alert (existing)
          if (newProg >= 75 && newProg < 77) {
            setSmsAlert({ show: true, message: `Ambulance ${em.driver.ambulanceNo} approaching within 500m of ${em.hospital}`, ambulance: em.driver.ambulanceNo })
            setTimeout(() => setSmsAlert({ show: false, message: '', ambulance: '' }), 5000)
          }

          // Citizen proximity detection — check if ambulance is within 500m of nearby citizens
          const ambTop = 27 + (newProg / 100) * 40
          const ambLeft = 20 + (newProg / 100) * 62
          const triggeredCitizens: CitizenSmsLog[] = []
          NEARBY_CITIZENS.forEach(citizen => {
            const dist = Math.sqrt(Math.pow(ambTop - citizen.mapTop, 2) + Math.pow(ambLeft - citizen.mapLeft, 2))
            const alertKey = `${emergencyId}-${citizen.id}`
            if (dist < 12 && !alertedCitizensRef.current.has(alertKey)) {
              alertedCitizensRef.current.add(alertKey)
              const smsLog: CitizenSmsLog = {
                id: `SMS-${Date.now()}-${citizen.id}`,
                citizenId: citizen.id,
                citizenName: citizen.name,
                phone: citizen.phone,
                location: citizen.location,
                ambulanceNo: em.driver.ambulanceNo,
                message: `EMERGENCY ALERT: Ambulance ${em.driver.ambulanceNo} approaching your area (${citizen.location}). Please clear the road immediately. Patient emergency: ${em.patientCondition}. Move to the side of the road and allow the ambulance to pass.`,
                timestamp: new Date().toLocaleTimeString(),
                delivered: true,
              }
              triggeredCitizens.push(smsLog)
            }
          })

          if (triggeredCitizens.length > 0) {
            setCitizenSmsLogs(prev => [...triggeredCitizens, ...prev])
            setCitizenAlert({ show: true, citizens: triggeredCitizens })
            triggerVibration()
            setTimeout(() => setCitizenAlert({ show: false, citizens: [] }), 6000)
          }

          return { ...em, animProgress: Math.min(newProg, 100), status: newStatus }
        })
        if (updated.find(em => em.id === emergencyId)?.animProgress === 100) {
          clearInterval(interval)
        }
        return updated
      })
    }, 200)
    return interval
  }, [setEmergencies, setSmsAlert, triggerVibration])

  const handleDispatch = async () => {
    if (!form.accidentLocation || !form.hospital || !form.driver || !form.patientCondition) {
      setError('Please fill in all required fields')
      return
    }
    setError('')
    setLoading(true)
    const driverObj = DRIVERS.find(d => d.id === form.driver)
    const message = `Emergency dispatch request: Accident at ${form.accidentLocation} (Lat: ${form.accidentLat}, Lng: ${form.accidentLng}). Patient condition: ${form.patientCondition}. Assigned ambulance: ${driverObj?.ambulanceNo ?? 'N/A'}, Driver: ${driverObj?.name ?? 'N/A'}. Destination hospital: ${form.hospital}. Please provide ETA estimate, route recommendation, hospital notification, dispatch briefing, severity level, and recommended actions.`

    try {
      const result = await callAIAgent(message, DISPATCH_AGENT_ID)
      if (result.success) {
        const parsed = parseLLMJson(result?.response?.result || result?.response)
        const dsMatch = DEMO_DATASETS.find(d => d.accidentLocation === form.accidentLocation)
        const newEmergency: Emergency = {
          id: `EM-${Date.now()}`,
          accidentLocation: form.accidentLocation,
          accidentLat: parseFloat(form.accidentLat) || dsMatch?.accidentLat || 0,
          accidentLng: parseFloat(form.accidentLng) || dsMatch?.accidentLng || 0,
          hospital: form.hospital,
          hospitalLat: dsMatch?.hospitalLat || 0,
          hospitalLng: dsMatch?.hospitalLng || 0,
          driver: driverObj || DRIVERS[0],
          patientCondition: form.patientCondition,
          status: 'dispatched',
          eta: parsed?.eta_estimate ?? 'Calculating...',
          dispatchBriefing: parsed?.dispatch_briefing ?? '',
          routeRecommendation: parsed?.route_recommendation ?? null,
          hospitalNotification: parsed?.hospital_notification ?? null,
          severityLevel: parsed?.severity_level ?? 'HIGH',
          recommendedActions: Array.isArray(parsed?.recommended_actions) ? parsed.recommended_actions : [],
          animProgress: 0,
          timestamp: new Date().toLocaleTimeString(),
        }
        setEmergencies(prev => [newEmergency, ...prev])
        setLatestDispatch(parsed)
        startAnimation(newEmergency.id)
        setForm({ accidentLocation: '', accidentLat: '', accidentLng: '', hospital: '', driver: '', patientCondition: '' })
        setSelectedDataset('')
      } else {
        setError(result?.error ?? 'Dispatch failed. Please try again.')
      }
    } catch {
      setError('Network error. Please try again.')
    }
    setLoading(false)
  }

  useEffect(() => { return () => { if (animRef.current) clearInterval(animRef.current) } }, [])

  const filteredEmergencies = emergencies.filter(em => filterStatus === 'all' ? true : em.status === filterStatus)
  const stats = {
    total: emergencies.length,
    active: emergencies.filter(e => e.status === 'dispatched').length,
    enRoute: emergencies.filter(e => e.status === 'en-route').length,
    completed: emergencies.filter(e => e.status === 'completed').length,
  }

  const latestActive = emergencies.find(e => e.status !== 'completed')

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: FiActivity },
    { id: 'emergencies', label: 'Emergencies', icon: FiAlertTriangle },
    { id: 'map', label: 'Map', icon: FiMapPin },
    { id: 'alerts', label: 'Alerts', icon: FiPhone },
  ]

  const statusBadge = (status: string) => {
    const styles: Record<string, string> = {
      dispatched: 'bg-red-100 text-red-700 border-red-200',
      'en-route': 'bg-amber-100 text-amber-700 border-amber-200',
      completed: 'bg-green-100 text-green-700 border-green-200',
    }
    const dots: Record<string, string> = { dispatched: 'bg-red-500', 'en-route': 'bg-amber-500', completed: 'bg-green-500' }
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full border ${styles[status] ?? 'bg-gray-100 text-gray-600'}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${dots[status] ?? 'bg-gray-400'} animate-pulse`} />
        {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
      </span>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(350,35%,97%)] via-[hsl(340,30%,95%)] to-[hsl(330,25%,96%)] flex">
      {/* Sidebar */}
      <aside className="w-64 min-h-screen backdrop-blur-[16px] bg-white/60 border-r border-white/[0.18] flex flex-col">
        <div className="p-5 flex items-center gap-2 border-b border-border/50">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <FiTruck className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-semibold tracking-tight text-foreground">RapidRoute</span>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {menuItems.map(item => (
            <button key={item.id} onClick={() => setActiveMenu(item.id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-[0.625rem] text-sm font-medium transition-all duration-200 ${activeMenu === item.id ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'}`}>
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-border/50 space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <FiUser className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{user.username}</p>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Control Room</Badge>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onLogout} className="w-full justify-start text-muted-foreground">
            <FiLogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Panel */}
        <div className="w-[42%] border-r border-border/30 overflow-y-auto p-5 space-y-5">
          {/* Stats */}
          <div className="grid grid-cols-5 gap-2.5">
            {[
              { label: 'Total', val: stats.total, color: 'text-foreground', bg: 'bg-primary/5' },
              { label: 'Active', val: stats.active, color: 'text-red-600', bg: 'bg-red-50' },
              { label: 'En-Route', val: stats.enRoute, color: 'text-amber-600', bg: 'bg-amber-50' },
              { label: 'Done', val: stats.completed, color: 'text-green-600', bg: 'bg-green-50' },
              { label: 'SMS Sent', val: citizenSmsLogs.length, color: 'text-orange-600', bg: 'bg-orange-50' },
            ].map(s => (
              <div key={s.label} className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] p-3 text-center shadow-sm">
                <p className={`text-2xl font-semibold ${s.color}`}>{s.val}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Dispatch Form */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiSend className="w-4 h-4 text-primary" /> Dispatch Ambulance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs mb-1 block">Quick Dataset</Label>
                <Select value={selectedDataset} onValueChange={handleDatasetChange}>
                  <SelectTrigger className="rounded-[0.625rem] h-9 text-sm"><SelectValue placeholder="Select preset dataset..." /></SelectTrigger>
                  <SelectContent>{DEMO_DATASETS.map(d => <SelectItem key={d.id} value={d.id.toString()}>{d.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs mb-1 block">Accident Location *</Label>
                <Input placeholder="e.g. Marine Drive, Mumbai" className="rounded-[0.625rem] h-9 text-sm" value={form.accidentLocation} onChange={e => setForm(prev => ({ ...prev, accidentLocation: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label className="text-xs mb-1 block">Latitude</Label><Input placeholder="19.0760" className="rounded-[0.625rem] h-9 text-sm" value={form.accidentLat} onChange={e => setForm(prev => ({ ...prev, accidentLat: e.target.value }))} /></div>
                <div><Label className="text-xs mb-1 block">Longitude</Label><Input placeholder="72.8777" className="rounded-[0.625rem] h-9 text-sm" value={form.accidentLng} onChange={e => setForm(prev => ({ ...prev, accidentLng: e.target.value }))} /></div>
              </div>
              <div>
                <Label className="text-xs mb-1 block">Hospital *</Label>
                <Select value={form.hospital} onValueChange={v => setForm(prev => ({ ...prev, hospital: v }))}>
                  <SelectTrigger className="rounded-[0.625rem] h-9 text-sm"><SelectValue placeholder="Select hospital..." /></SelectTrigger>
                  <SelectContent>{HOSPITALS.map(h => <SelectItem key={h} value={h}>{h}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs mb-1 block">Assign Driver *</Label>
                <Select value={form.driver} onValueChange={v => setForm(prev => ({ ...prev, driver: v }))}>
                  <SelectTrigger className="rounded-[0.625rem] h-9 text-sm"><SelectValue placeholder="Select driver..." /></SelectTrigger>
                  <SelectContent>{DRIVERS.map(d => <SelectItem key={d.id} value={d.id}>{d.name} - {d.ambulanceNo}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs mb-1 block">Patient Condition *</Label>
                <Select value={form.patientCondition} onValueChange={v => setForm(prev => ({ ...prev, patientCondition: v }))}>
                  <SelectTrigger className="rounded-[0.625rem] h-9 text-sm"><SelectValue placeholder="Select condition..." /></SelectTrigger>
                  <SelectContent>{PATIENT_CONDITIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {error && <p className="text-destructive text-xs bg-destructive/10 px-3 py-2 rounded-lg">{error}</p>}
              <Button onClick={handleDispatch} disabled={loading} className="w-full rounded-[0.625rem] h-10 font-semibold">
                {loading ? <><BiLoaderAlt className="w-4 h-4 mr-2 animate-spin" /> Dispatching...</> : <><FiSend className="w-4 h-4 mr-1" /> Dispatch Ambulance</>}
              </Button>
            </CardContent>
          </Card>

          {/* Emergencies List */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiAlertTriangle className="w-4 h-4 text-primary" /> Active Emergencies
              </CardTitle>
              <div className="flex gap-1 mt-2">
                {['all', 'dispatched', 'en-route', 'completed'].map(s => (
                  <button key={s} onClick={() => setFilterStatus(s)} className={`px-2.5 py-1 text-xs rounded-full font-medium transition-all ${filterStatus === s ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}>
                    {s.charAt(0).toUpperCase() + s.slice(1).replace('-', ' ')}
                  </button>
                ))}
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px]">
                {filteredEmergencies.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">No emergencies found</div>
                ) : (
                  <div className="space-y-2">
                    {filteredEmergencies.map(em => (
                      <div key={em.id} className="p-3 rounded-[0.625rem] bg-white/50 border border-border/30 hover:bg-white/70 transition-all">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-mono text-muted-foreground">{em.id}</span>
                          {statusBadge(em.status)}
                        </div>
                        <p className="text-sm font-medium text-foreground">{em.accidentLocation}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><FiUser className="w-3 h-3" />{em.driver.name}</span>
                          <span className="flex items-center gap-1"><FiTruck className="w-3 h-3" />{em.driver.ambulanceNo}</span>
                          <span className="flex items-center gap-1"><FiClock className="w-3 h-3" />{em.eta}</span>
                        </div>
                        {em.status !== 'completed' && (
                          <div className="mt-2 w-full bg-muted/50 rounded-full h-1.5">
                            <div className="bg-primary h-1.5 rounded-full transition-all duration-300" style={{ width: `${em.animProgress}%` }} />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Hospital Notification */}
          {latestActive && latestActive.hospitalNotification && (
            <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md border-l-4 border-l-primary">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                  <HiOutlineStatusOnline className="w-4 h-4 text-primary" /> Hospital Notification
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <p className="text-foreground">{latestActive.hospitalNotification?.message ?? ''}</p>
                {latestActive.hospitalNotification?.priority_level && (
                  <Badge variant="destructive" className="text-xs">{latestActive.hospitalNotification.priority_level}</Badge>
                )}
                {latestActive.hospitalNotification?.patient_summary && (
                  <p className="text-muted-foreground text-xs">{latestActive.hospitalNotification.patient_summary}</p>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Panel - Map + Briefing */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Simulated Map */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiMapPin className="w-4 h-4 text-primary" /> Live Map View
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative h-[300px] bg-gradient-to-br from-green-100/60 via-emerald-50/40 to-teal-100/60 overflow-hidden">
                {/* Grid Lines */}
                <div className="absolute inset-0 opacity-10">
                  {[...Array(10)].map((_, i) => (
                    <React.Fragment key={i}>
                      <div className="absolute h-px bg-foreground/30 w-full" style={{ top: `${(i + 1) * 10}%` }} />
                      <div className="absolute w-px bg-foreground/30 h-full" style={{ left: `${(i + 1) * 10}%` }} />
                    </React.Fragment>
                  ))}
                </div>
                {/* Roads */}
                <div className="absolute top-[30%] left-0 right-0 h-1 bg-gray-300/60" />
                <div className="absolute top-[60%] left-0 right-0 h-0.5 bg-gray-300/40" />
                <div className="absolute left-[25%] top-0 bottom-0 w-0.5 bg-gray-300/40" />
                <div className="absolute left-[65%] top-0 bottom-0 w-1 bg-gray-300/60" />

                {latestActive ? (
                  <>
                    {/* Accident marker */}
                    <div className="absolute top-[25%] left-[20%] z-10">
                      <div className="w-5 h-5 bg-red-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center animate-pulse">
                        <FiAlertTriangle className="w-3 h-3 text-white" />
                      </div>
                      <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] font-medium text-red-600 whitespace-nowrap bg-white/80 px-1 rounded">Accident</span>
                    </div>
                    {/* Hospital marker */}
                    <div className="absolute top-[65%] right-[18%] z-10">
                      <div className="w-5 h-5 bg-blue-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                        <span className="text-[8px] font-bold text-white">H</span>
                      </div>
                      <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] font-medium text-blue-600 whitespace-nowrap bg-white/80 px-1 rounded">{latestActive.hospital}</span>
                    </div>
                    {/* Route line */}
                    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                      <path d="M20,27 C35,27 40,35 50,45 C60,55 70,65 82,67" fill="none" stroke="hsl(346,77%,50%)" strokeWidth="0.6" strokeDasharray="2,1" opacity="0.7" />
                    </svg>
                    {/* Ambulance dot along route */}
                    <div className="absolute z-20 transition-all duration-200" style={{ top: `${27 + (latestActive.animProgress / 100) * 40}%`, left: `${20 + (latestActive.animProgress / 100) * 62}%`, transform: 'translate(-50%,-50%)' }}>
                      <div className="relative">
                        <div className="w-6 h-6 bg-primary rounded-full border-2 border-white shadow-xl flex items-center justify-center animate-pulse">
                          <FiTruck className="w-3 h-3 text-primary-foreground" />
                        </div>
                        {/* 500m radius circle */}
                        <div className="absolute -inset-4 border-2 border-primary/20 rounded-full animate-ping" style={{ animationDuration: '2s' }} />
                      </div>
                    </div>

                    {/* Nearby Citizens / Traffic Signal Markers */}
                    {NEARBY_CITIZENS.map(citizen => {
                      const ambTop = 27 + (latestActive.animProgress / 100) * 40
                      const ambLeft = 20 + (latestActive.animProgress / 100) * 62
                      const dist = Math.sqrt(Math.pow(ambTop - citizen.mapTop, 2) + Math.pow(ambLeft - citizen.mapLeft, 2))
                      const isInRange = dist < 12
                      return (
                        <div key={citizen.id} className="absolute z-10 transition-all duration-300" style={{ top: `${citizen.mapTop}%`, left: `${citizen.mapLeft}%`, transform: 'translate(-50%,-50%)' }}>
                          <div className={`relative w-4 h-4 rounded-full border border-white shadow flex items-center justify-center transition-all duration-300 ${isInRange ? 'bg-orange-500 scale-125' : 'bg-yellow-400'}`}>
                            <FiSmartphone className="w-2.5 h-2.5 text-white" />
                            {isInRange && (
                              <div className="absolute -inset-2 border border-orange-400/40 rounded-full animate-ping" style={{ animationDuration: '1s' }} />
                            )}
                          </div>
                          <span className={`absolute -bottom-4 left-1/2 -translate-x-1/2 text-[7px] font-medium whitespace-nowrap px-1 rounded ${isInRange ? 'bg-orange-100 text-orange-700' : 'bg-white/70 text-gray-500'}`}>
                            {citizen.location.split(' - ')[1] || citizen.location.split(' - ')[0]}
                          </span>
                        </div>
                      )
                    })}

                    {/* Traffic Signal Zones (decorative) */}
                    <div className="absolute top-[29%] left-[37%] w-2 h-2 rounded-full bg-red-400 opacity-70 animate-pulse" />
                    <div className="absolute top-[29%] left-[64%] w-2 h-2 rounded-full bg-green-400 opacity-70 animate-pulse" style={{ animationDelay: '0.5s' }} />
                    <div className="absolute top-[59%] left-[25%] w-2 h-2 rounded-full bg-amber-400 opacity-70 animate-pulse" style={{ animationDelay: '1s' }} />
                  </>
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm">
                    <div className="text-center">
                      <FiMapPin className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      <p>No active emergencies on map</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Alert Activity Log */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                <FiActivity className="w-4 h-4 text-primary" /> Activity Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[140px]">
                {emergencies.length === 0 ? (
                  <p className="text-muted-foreground text-sm text-center py-4">No activity yet. Dispatch an ambulance to begin.</p>
                ) : (
                  <div className="space-y-2">
                    {emergencies.map(em => (
                      <div key={em.id} className="flex items-start gap-2 text-xs">
                        <span className="text-muted-foreground shrink-0">{em.timestamp}</span>
                        <span className="text-foreground">
                          <strong>{em.driver.name}</strong> dispatched to <strong>{em.accidentLocation}</strong> ({em.patientCondition})
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Citizen SMS Alerts Log */}
          <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md border-l-4 border-l-orange-400">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                  <FiRadio className="w-4 h-4 text-orange-500" /> Citizen SMS Alerts
                </CardTitle>
                <Badge className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-100 text-xs">
                  {citizenSmsLogs.length} sent
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Location-based SMS alerts sent to citizens near traffic signals and jam zones within 500m of ambulance</p>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[180px]">
                {citizenSmsLogs.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <FiSmartphone className="w-6 h-6 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No citizen alerts triggered yet</p>
                    <p className="text-xs mt-0.5">Alerts are sent automatically when ambulance is within 500m of citizens near traffic signals</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {citizenSmsLogs.map(log => (
                      <div key={log.id} className="p-2.5 rounded-[0.625rem] bg-orange-50/50 border border-orange-200/40 hover:bg-orange-50/80 transition-all">
                        <div className="flex items-center justify-between mb-1">
                          <span className="flex items-center gap-1.5 text-xs font-medium text-orange-700">
                            <FiBell className="w-3 h-3" /> SMS Sent with Vibration
                          </span>
                          <span className="flex items-center gap-1 text-[10px] text-green-600 font-medium">
                            <FiCheckCircle className="w-3 h-3" /> Delivered
                          </span>
                        </div>
                        <p className="text-xs text-foreground leading-relaxed">{log.message}</p>
                        <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
                          <span className="flex items-center gap-1"><FiSmartphone className="w-2.5 h-2.5" />{log.phone}</span>
                          <span className="flex items-center gap-1"><FiMapPin className="w-2.5 h-2.5" />{log.location}</span>
                          <span className="flex items-center gap-1"><FiClock className="w-2.5 h-2.5" />{log.timestamp}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Dispatch Briefing */}
          {latestDispatch && (
            <Card className="backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold tracking-tight flex items-center gap-2">
                  <FiCheckCircle className="w-4 h-4 text-green-600" /> Latest Dispatch Briefing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                {latestDispatch.eta_estimate && (
                  <div className="flex items-center gap-2">
                    <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/10"><FiClock className="w-3 h-3 mr-1" /> ETA: {latestDispatch.eta_estimate}</Badge>
                    {latestDispatch.severity_level && <Badge variant="destructive" className="text-xs">{latestDispatch.severity_level}</Badge>}
                  </div>
                )}
                {latestDispatch.dispatch_briefing && <p className="text-foreground leading-relaxed">{latestDispatch.dispatch_briefing}</p>}
                {latestDispatch.route_recommendation && (
                  <div className="bg-muted/30 rounded-lg p-3 space-y-1">
                    <p className="font-medium text-xs text-muted-foreground uppercase tracking-wider">Route Recommendation</p>
                    <p className="text-foreground">{latestDispatch.route_recommendation?.selected_route ?? ''}</p>
                    <p className="text-muted-foreground text-xs">{latestDispatch.route_recommendation?.reasoning ?? ''}</p>
                    {Array.isArray(latestDispatch.route_recommendation?.alternative_routes) && latestDispatch.route_recommendation.alternative_routes.length > 0 && (
                      <div className="mt-1">
                        <p className="text-xs text-muted-foreground">Alternatives:</p>
                        <ul className="list-disc ml-4 text-xs text-muted-foreground">
                          {latestDispatch.route_recommendation.alternative_routes.map((r: string, i: number) => <li key={i}>{r}</li>)}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
                {Array.isArray(latestDispatch.recommended_actions) && latestDispatch.recommended_actions.length > 0 && (
                  <div>
                    <p className="font-medium text-xs text-muted-foreground uppercase tracking-wider mb-1">Recommended Actions</p>
                    <ul className="space-y-1">
                      {latestDispatch.recommended_actions.map((a: string, i: number) => (
                        <li key={i} className="flex items-start gap-2 text-foreground text-xs">
                          <FiCheckCircle className="w-3 h-3 text-green-500 mt-0.5 shrink-0" />{a}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Agent Info */}
          <div className="backdrop-blur-[16px] bg-white/50 border border-white/[0.18] rounded-[0.875rem] p-3">
            <p className="text-xs text-muted-foreground mb-1 font-medium">Powered by AI Agents</p>
            <div className="flex items-center gap-2 text-xs">
              <span className={`w-2 h-2 rounded-full ${loading ? 'bg-amber-400 animate-pulse' : 'bg-green-400'}`} />
              <span className="text-foreground">Emergency Dispatch Agent</span>
              <span className="text-muted-foreground font-mono text-[10px]">{DISPATCH_AGENT_ID.slice(0, 8)}...</span>
            </div>
          </div>
        </div>
      </main>

      {/* SMS Alert Popup - Hospital Proximity */}
      {smsAlert.show && (
        <div className="fixed bottom-6 right-6 z-50 w-72 animate-bounce">
          <div className="bg-white rounded-2xl shadow-2xl border border-border overflow-hidden">
            <div className="bg-primary px-4 py-2 flex items-center justify-between">
              <span className="text-primary-foreground text-xs font-semibold flex items-center gap-1.5"><FiAlertTriangle className="w-3.5 h-3.5" /> Emergency Alert</span>
              <button onClick={() => setSmsAlert({ show: false, message: '', ambulance: '' })}><FiX className="w-3.5 h-3.5 text-primary-foreground/80" /></button>
            </div>
            <div className="p-4 space-y-2">
              <p className="text-sm text-foreground font-medium">{smsAlert.message}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <FiTruck className="w-3 h-3" />{smsAlert.ambulance}
                <FiNavigation className="w-3 h-3 ml-2" />Approaching
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Citizen SMS Alert Popup - Location Based with Vibration */}
      {citizenAlert.show && citizenAlert.citizens.length > 0 && (
        <div className="fixed bottom-24 right-6 z-50 w-80" style={{ animation: 'citizenVibrate 0.4s ease-in-out 3' }}>
          <div className="bg-white rounded-2xl shadow-2xl border-2 border-orange-300 overflow-hidden">
            {/* Phone-style header */}
            <div className="bg-gradient-to-r from-orange-500 to-red-500 px-4 py-2.5 flex items-center justify-between">
              <span className="text-white text-xs font-bold flex items-center gap-2">
                <FiSmartphone className="w-4 h-4" />
                <span>CITIZEN SMS ALERT</span>
                <span className="inline-flex items-center justify-center w-5 h-5 bg-white/20 rounded-full text-[10px]">{citizenAlert.citizens.length}</span>
              </span>
              <button onClick={() => setCitizenAlert({ show: false, citizens: [] })}>
                <FiX className="w-4 h-4 text-white/80" />
              </button>
            </div>
            {/* Vibration indicator bar */}
            <div className="bg-orange-50 px-4 py-1.5 border-b border-orange-200 flex items-center gap-2">
              <div className="flex gap-0.5">
                <div className="w-1 h-3 bg-orange-400 rounded-full" style={{ animation: 'vibrateBar 0.3s ease-in-out infinite' }} />
                <div className="w-1 h-4 bg-orange-500 rounded-full" style={{ animation: 'vibrateBar 0.3s ease-in-out infinite 0.1s' }} />
                <div className="w-1 h-2 bg-orange-400 rounded-full" style={{ animation: 'vibrateBar 0.3s ease-in-out infinite 0.2s' }} />
                <div className="w-1 h-5 bg-orange-600 rounded-full" style={{ animation: 'vibrateBar 0.3s ease-in-out infinite 0.05s' }} />
                <div className="w-1 h-3 bg-orange-400 rounded-full" style={{ animation: 'vibrateBar 0.3s ease-in-out infinite 0.15s' }} />
              </div>
              <span className="text-[10px] font-semibold text-orange-600 uppercase tracking-widest">Strong Vibration Active</span>
            </div>
            {/* Alert content */}
            <div className="p-3 space-y-2 max-h-[200px] overflow-y-auto">
              {citizenAlert.citizens.map(c => (
                <div key={c.id} className="bg-orange-50/80 rounded-lg p-2.5 border border-orange-200/50">
                  <div className="flex items-center gap-2 mb-1">
                    <FiMapPin className="w-3 h-3 text-orange-600 shrink-0" />
                    <span className="text-xs font-semibold text-orange-800">{c.location}</span>
                  </div>
                  <p className="text-[11px] text-foreground leading-relaxed">{c.message}</p>
                  <div className="flex items-center gap-2 mt-1.5 text-[10px] text-muted-foreground">
                    <FiPhone className="w-2.5 h-2.5" />{c.phone}
                    <FiCheckCircle className="w-2.5 h-2.5 text-green-500 ml-1" />
                    <span className="text-green-600">Delivered</span>
                  </div>
                </div>
              ))}
            </div>
            {/* Footer */}
            <div className="bg-gray-50 px-4 py-2 border-t border-border/50 flex items-center justify-between">
              <span className="text-[10px] text-muted-foreground">Location-based alert within 500m radius</span>
              <FiRadio className="w-3 h-3 text-orange-500 animate-pulse" />
            </div>
          </div>
        </div>
      )}

      {/* Vibration animation styles */}
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes citizenVibrate {
          0%, 100% { transform: translateX(0) rotate(0deg); }
          10% { transform: translateX(-4px) rotate(-1deg); }
          20% { transform: translateX(4px) rotate(1deg); }
          30% { transform: translateX(-6px) rotate(-1.5deg); }
          40% { transform: translateX(6px) rotate(1.5deg); }
          50% { transform: translateX(-4px) rotate(-1deg); }
          60% { transform: translateX(4px) rotate(1deg); }
          70% { transform: translateX(-3px) rotate(-0.5deg); }
          80% { transform: translateX(3px) rotate(0.5deg); }
          90% { transform: translateX(-1px) rotate(0deg); }
        }
        @keyframes vibrateBar {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(0.4); }
        }
      ` }} />
    </div>
  )
}
