'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { FiShield, FiTruck, FiUser, FiLock, FiArrowRight } from 'react-icons/fi'

interface LoginSectionProps {
  onLogin: (user: { username: string; role: 'control-room' | 'driver' }) => void
}

export default function LoginSection({ onLogin }: LoginSectionProps) {
  const [role, setRole] = useState<'control-room' | 'driver'>('control-room')
  const [loginForm, setLoginForm] = useState({ username: '', password: '' })
  const [registerForm, setRegisterForm] = useState({ username: '', password: '', confirm: '' })
  const [error, setError] = useState('')

  const handleLogin = () => {
    setError('')
    if (!loginForm.username.trim() || !loginForm.password.trim()) {
      setError('Please fill in all fields')
      return
    }
    onLogin({ username: loginForm.username, role })
  }

  const handleRegister = () => {
    setError('')
    if (!registerForm.username.trim() || !registerForm.password.trim() || !registerForm.confirm.trim()) {
      setError('Please fill in all fields')
      return
    }
    if (registerForm.password !== registerForm.confirm) {
      setError('Passwords do not match')
      return
    }
    onLogin({ username: registerForm.username, role })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(350,35%,97%)] via-[hsl(340,30%,95%)] to-[hsl(330,25%,96%)] flex items-center justify-center p-4">
      <Card className="w-full max-w-md backdrop-blur-[16px] bg-white/75 border border-white/[0.18] rounded-[0.875rem] shadow-xl">
        <CardHeader className="text-center pb-2">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-10 h-10 rounded-[0.875rem] bg-primary flex items-center justify-center">
              <FiTruck className="w-5 h-5 text-primary-foreground" />
            </div>
            <CardTitle className="text-2xl font-semibold tracking-tight text-foreground">RapidRoute</CardTitle>
          </div>
          <CardDescription className="text-muted-foreground">Smart Ambulance Routing System</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Role Toggle */}
          <div className="flex rounded-[0.875rem] bg-muted p-1 gap-1">
            <button
              onClick={() => setRole('control-room')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-[0.625rem] text-sm font-medium transition-all duration-200 ${role === 'control-room' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
            >
              <FiShield className="w-4 h-4" />
              Control Room
            </button>
            <button
              onClick={() => setRole('driver')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-[0.625rem] text-sm font-medium transition-all duration-200 ${role === 'driver' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
            >
              <FiTruck className="w-4 h-4" />
              Driver
            </button>
          </div>

          {error && (
            <div className="bg-destructive/10 text-destructive text-sm px-3 py-2 rounded-[0.625rem] border border-destructive/20">
              {error}
            </div>
          )}

          <Tabs defaultValue="login" className="w-full">
            <TabsList className="w-full">
              <TabsTrigger value="login" className="flex-1">Login</TabsTrigger>
              <TabsTrigger value="register" className="flex-1">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="login-user" className="text-foreground">Username</Label>
                <div className="relative">
                  <FiUser className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="login-user"
                    placeholder="Enter username"
                    className="pl-10 rounded-[0.625rem]"
                    value={loginForm.username}
                    onChange={(e) => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-pass" className="text-foreground">Password</Label>
                <div className="relative">
                  <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="login-pass"
                    type="password"
                    placeholder="Enter password"
                    className="pl-10 rounded-[0.625rem]"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  />
                </div>
              </div>
              <Button onClick={handleLogin} className="w-full rounded-[0.625rem] h-11 font-semibold">
                Login
                <FiArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </TabsContent>

            <TabsContent value="register" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="reg-user" className="text-foreground">Username</Label>
                <div className="relative">
                  <FiUser className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="reg-user"
                    placeholder="Choose username"
                    className="pl-10 rounded-[0.625rem]"
                    value={registerForm.username}
                    onChange={(e) => setRegisterForm(prev => ({ ...prev, username: e.target.value }))}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-pass" className="text-foreground">Password</Label>
                <div className="relative">
                  <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="reg-pass"
                    type="password"
                    placeholder="Create password"
                    className="pl-10 rounded-[0.625rem]"
                    value={registerForm.password}
                    onChange={(e) => setRegisterForm(prev => ({ ...prev, password: e.target.value }))}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-confirm" className="text-foreground">Confirm Password</Label>
                <div className="relative">
                  <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="reg-confirm"
                    type="password"
                    placeholder="Confirm password"
                    className="pl-10 rounded-[0.625rem]"
                    value={registerForm.confirm}
                    onChange={(e) => setRegisterForm(prev => ({ ...prev, confirm: e.target.value }))}
                  />
                </div>
              </div>
              <Button onClick={handleRegister} className="w-full rounded-[0.625rem] h-11 font-semibold">
                Create Account
                <FiArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
