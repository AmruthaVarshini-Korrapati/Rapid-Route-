'use client'

import React, { useState } from 'react'
import LoginSection from './sections/LoginSection'
import ControlRoomSection from './sections/ControlRoomSection'
import DriverDashboardSection from './sections/DriverDashboardSection'
import type { Emergency } from './sections/ControlRoomSection'

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props)
    this.state = { hasError: false, error: '' }
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error: error.message }
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
          <div className="text-center p-8 max-w-md">
            <h2 className="text-xl font-semibold mb-2">Something went wrong</h2>
            <p className="text-muted-foreground mb-4 text-sm">{this.state.error}</p>
            <button
              onClick={() => this.setState({ hasError: false, error: '' })}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm"
            >
              Try again
            </button>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

export default function Page() {
  const [user, setUser] = useState<{ username: string; role: 'control-room' | 'driver' } | null>(null)
  const [emergencies, setEmergencies] = useState<Emergency[]>([])
  const [smsAlert, setSmsAlert] = useState<{ show: boolean; message: string; ambulance: string }>({ show: false, message: '', ambulance: '' })

  return (
    <ErrorBoundary>
      {!user ? (
        <LoginSection onLogin={(u) => setUser(u)} />
      ) : user.role === 'control-room' ? (
        <ControlRoomSection
          user={user}
          onLogout={() => setUser(null)}
          emergencies={emergencies}
          setEmergencies={setEmergencies}
          smsAlert={smsAlert}
          setSmsAlert={setSmsAlert}
        />
      ) : (
        <DriverDashboardSection
          user={user}
          onLogout={() => setUser(null)}
          emergencies={emergencies}
        />
      )}
    </ErrorBoundary>
  )
}
